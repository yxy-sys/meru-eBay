# Mercari → eBay Qty=0 (Google Sheets Ledger)
Monitors **Mercari (jp.mercari.com)** item pages. If SOLD/売り切れ is detected, it sets the corresponding **eBay** listing quantity to **0**.
The ledger (mapping of Mercari URLs to eBay ItemID/SKU) is read **from Google Sheets**.

## Two ways to read the Sheet
### Mode A: PUBLIC_CSV (easiest)
1. In Google Sheets: File → Share → Publish to the web → Entire Sheet → CSV → Publish.
2. Copy the CSV URL.
3. Put it in `.env` as `SHEETS_MODE=PUBLIC_CSV` and `SHEET_CSV_URL=<that url>`.

### Mode B: SERVICE_API (private sheet via service account)
1. Create a Google Cloud project → Enable "Google Sheets API".
2. Create a Service Account and download the JSON key file.
3. Share your Google Sheet to **the service account email** (Editor or Viewer).
4. Put the JSON file path in `.env` as `GOOGLE_SERVICE_ACCOUNT_JSON=service_account.json`.
5. Put `SHEETS_MODE=SERVICE_API`, `SHEET_ID=<your sheet id>`, `SHEET_RANGE='Sheet1!A:D'`.

> You can drop your `service_account.json` in the project folder (DON'T commit it publicly).
> If you prefer, you can mount it as a secret file in Render/Replit and set the path accordingly.

## Expected headers in the Sheet (row 1)
- `source_url` (Mercari item URL)
- `ebay_item_id` (optional if `sku` is used)
- `sku` (optional; if provided, we update that variation only)
- `trigger` (optional: `soldout` or `lowstock`, default `soldout`)

## Run
1) `pip install -r requirements.txt`
2) Copy `.env.example` to `.env`, fill eBay keys and Sheet config.
3) Test (dry mode): `python main_gsheets.py`
4) Real run: set `DRY_RUN=false` in `.env` and run again.
5) Schedule every 10–15 minutes on Render/Replit.

## Notes
- This package only handles Mercari. For multi-source, use the universal package.
- If you prefer **Sheet tab name** different from `Sheet1`, change `SHEET_RANGE` like `Inventory!A:D`.

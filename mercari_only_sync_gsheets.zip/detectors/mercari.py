from bs4 import BeautifulSoup

def detect(html: str):
    """Return OUT_OF_STOCK | IN_STOCK | UNKNOWN for Mercari page."""
    soup = BeautifulSoup(html, "lxml")
    text = soup.get_text(" ", strip=True).lower()
    if (" sold " in text) or ("売り切れ" in text) or ("売り切れました" in text):
        return "OUT_OF_STOCK"
    return "UNKNOWN"

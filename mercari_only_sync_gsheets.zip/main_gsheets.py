import os
from dotenv import load_dotenv
from sheet_reader import read_ledger
from fetcher import fetch
from detectors import mercari
from ebay_updater import revise_inventory_status
from notify import notify

load_dotenv()

def should_zero(trigger: str, status: str) -> bool:
    trig = (trigger or "soldout").lower()
    if trig == "soldout":
        return status == "OUT_OF_STOCK"
    if trig == "lowstock":
        return status in ("OUT_OF_STOCK", "LOW_STOCK")
    return False

def run_once():
    df = read_ledger()
    for _, row in df.iterrows():
        url = str(row.get("source_url", "") or "").strip().lower()
        if not url or ("mercari.com" not in url and "jp.mercari.com" not in url):
            continue
        item_id = str(row.get("ebay_item_id", "") or "").strip()
        sku = str(row.get("sku", "") or "").strip()
        trig = str(row.get("trigger", "") or "soldout").strip()
        code, html = fetch(url)
        status = "UNKNOWN" if code != 200 else mercari.detect(html)
        print(f"[MERCARI] {url} HTTP={code} status={status} trigger={trig} sku={sku}")
        if should_zero(trig, status):
            res = revise_inventory_status(item_id=item_id, sku=sku, quantity=0)
            print("eBay update:", res)
            ident = sku if sku else item_id
            notify(f"[MERCARI] {ident} -> Qty 0 ({status})")

if __name__ == "__main__":
    run_once()


import os, random, asyncio, requests

UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36",
]

def fetch_requests(url: str, timeout: int = 25):
    headers = {
        "User-Agent": random.choice(UA_POOL),
        "Accept-Language": "ja,en-US;q=0.9,en;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Connection": "close",
    }
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
        return resp.status_code, resp.text
    except Exception as e:
        return 0, str(e)

async def fetch_playwright_async(url: str):
    try:
        from playwright.async_api import async_playwright
    except Exception as e:
        return 0, f"Playwright not installed: {e}"
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True, args=["--no-sandbox"])
            context = await browser.new_context(locale="ja-JP")
            page = await context.new_page()
            await page.goto(url, wait_until="domcontentloaded", timeout=45000)
            try:
                await page.wait_for_timeout(1500)
            except:
                pass
            html = await page.content()
            await browser.close()
            return 200, html
    except Exception as e:
        return 0, str(e)

def fetch(url: str):
    mode = os.getenv("FETCH_MODE", "REQUESTS").upper()
    timeout = int(os.getenv("REQUESTS_TIMEOUT", "25"))
    if mode == "REQUESTS":
        return fetch_requests(url, timeout=timeout)
    if mode == "PLAYWRIGHT":
        return asyncio.run(fetch_playwright_async(url))
    if mode == "AUTO":
        code, html = fetch_requests(url, timeout=timeout)
        if code == 200 and ("売り切れ" in html or "SOLD" in html or "Sold" in html):
            return code, html
        pcode, phtml = asyncio.run(fetch_playwright_async(url))
        return (pcode or code), (phtml if pcode == 200 else html)
    return fetch_requests(url, timeout=timeout)


import os, requests
from xml.sax.saxutils import escape

EBAY_ENDPOINT = "https://api.ebay.com/ws/api.dll"

def revise_inventory_status(item_id: str = "", sku: str = "", quantity: int = 0) -> dict:
    dev_id = os.getenv("EBAY_DEV_ID")
    app_id = os.getenv("EBAY_APP_ID")
    cert_id = os.getenv("EBAY_CERT_ID")
    auth_token = os.getenv("EBAY_AUTH_TOKEN")
    if not all([dev_id, app_id, cert_id, auth_token]):
        return {"ok": False, "error": "Missing eBay credentials in environment"}

    headers = {
        "X-EBAY-API-SITEID": "0",
        "X-EBAY-API-CALL-NAME": "ReviseInventoryStatus",
        "X-EBAY-API-COMPATIBILITY-LEVEL": "1199",
        "X-EBAY-API-DEV-NAME": dev_id,
        "X-EBAY-API-APP-NAME": app_id,
        "X-EBAY-API-CERT-NAME": cert_id,
        "Content-Type": "text/xml",
    }

    inv = f"<SKU>{escape(sku)}</SKU>" if sku else f"<ItemID>{escape(str(item_id))}</ItemID>"

    body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" \           "<ReviseInventoryStatusRequest xmlns=\"urn:ebay:apis:eBLBaseComponents\">\n" \           "  <RequesterCredentials>\n" \           f"    <eBayAuthToken>{escape(auth_token)}</eBayAuthToken>\n" \           "  </RequesterCredentials>\n" \           "  <InventoryStatus>\n" \           f"    {inv}\n" \           f"    <Quantity>{quantity}</Quantity>\n" \           "  </InventoryStatus>\n" \           "</ReviseInventoryStatusRequest>\n"

    if os.getenv("DRY_RUN", "true").lower() == "true":
        return {"ok": True, "dry_run": True, "item_id": item_id, "sku": sku, "quantity": quantity}

    try:
        resp = requests.post(EBAY_ENDPOINT, data=body.encode("utf-8"), headers=headers, timeout=30)
        ok = (resp.status_code == 200) and ("<Ack>Success</Ack>" in resp.text or "<Ack>Warning</Ack>" in resp.text)
        return {"ok": ok, "status": resp.status_code, "body": resp.text[:5000]}
    except Exception as e:
        return {"ok": False, "error": str(e)}
